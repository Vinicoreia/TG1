#include <iostream>
#include <vector>
#include <unordered_map>
#include <cstdlib>
#include <string>

using namespace std;

unordered_map<int, int> yetVisited;

int **matrix;
int width = 0, height = 0;
int parts;


void FloodFill(int x, int y){
	if(matrix[x][y] == '.'){
		matrix[x][y] = 'd';
		yetVisited.erase(yetVisited.find(x*width + y));
		
		
		if((x-1) >= 0 && matrix[x - 1][y] == '.'){
			FloodFill(x-1, y);
		}
		if((x+1) < height && matrix[x + 1][y] == '.'){
			FloodFill(x + 1, y);
		}
		if((y-1) >= 0 && matrix[x][y - 1] == '.'){
			FloodFill(x, y - 1);
		}
		if((y+1) < width && matrix[x][y + 1] == '.'){
			FloodFill(x, y + 1);
		}
	}
}


void CheckConnections(){	
	parts = 0;
	if(yetVisited.empty())
		return;
	
	
	do{
		parts++;
		if(!yetVisited.empty())
			FloodFill(yetVisited.begin()->first/width, yetVisited.begin()->first%width);
		
		
	}while(!yetVisited.empty());
}



int main (){
	string line;
	
	cin>>height>>width;
	
	matrix = (int**)malloc(height*sizeof(int*));
	
	for(int i = 0;i < height; i++){
		*(matrix + i) = (int*)calloc(width, sizeof(int));
	}
	cin.ignore();
	
	for(int i = 0; i < height; i++){
		getline(cin, line, '\n');
		for(int j = 0; j < line.size(); j++){
			if(line[j] == '.'){
				matrix[i][j] = '.';
				yetVisited[i*width + j] = 1;
			}
		}
	}
	CheckConnections();
	cout<<parts<<endl;
	
	return 0;
}
