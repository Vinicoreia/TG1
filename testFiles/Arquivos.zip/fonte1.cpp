#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

vector<vector<int>> graph;
unordered_map<int, int> yetVisited;


int roadsNeeded;

void FloodFill(int node){
	if(yetVisited.find(node) != yetVisited.end()){
		yetVisited.erase(yetVisited.find(node));
		
		for(auto i = graph[node - 1].begin(); i != graph[node - 1].end(); i++){
			if(yetVisited.find(*i) != yetVisited.end())
				FloodFill(*i);
		}
		
	}
}

void CheckConnections(){
	roadsNeeded = -1;
	do{
	roadsNeeded++;
	FloodFill(yetVisited.begin()->first);
	}while(!yetVisited.empty());
}

int main(){
	int cases;
	
	cin>>cases;
	for(int currentCase = 1 ; currentCase <= cases; currentCase++){
		int points, roads;
		
		yetVisited.clear();
		graph.clear();
		
		cin>>points;
		cin>>roads;
		
		for(int i = 1; i <= points; i++){
			yetVisited[i] = 0;
		}
		
		graph.resize(points);
		
		while(roads--){
			int from, to;
			cin>>from>>to;
			
			graph[from - 1].emplace_back(to);
			graph[to - 1].emplace_back(from);
		}
		
		CheckConnections();
		
		if(roadsNeeded == 0)
			cout<<"Caso #"<<currentCase<<": a promessa foi cumprida\n";
		else
			cout<<"Caso #"<<currentCase<<": ainda falta(m) "<<roadsNeeded<<" estrada(s)\n";
	}
	
	return 0;
}
